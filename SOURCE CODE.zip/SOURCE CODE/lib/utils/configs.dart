import 'package:country_picker/country_picker.dart';
import 'package:flutter/material.dart';

const APP_NAME = 'Beautifier';
const APP_NAME_TAG_LINE = 'Discover and connect with your favorite makeup artists in just a few clicks.';
var defaultPrimaryColor = Color(0xFF832f63);


const DOMAIN_URL = 'https://beautifierapp.com'; // Don't add slash at the end of the url
const BASE_URL = '$DOMAIN_URL/api/';

const DEFAULT_LANGUAGE = 'ar';

/// You can change this to your Provider App package name
/// This will be used in Registered As Partner in Sign In Screen where your users can redirect to the Play/App Store for Provider App
/// You can specify in Admin Panel, These will be used if you don't specify in Admin Panel
const PROVIDER_PACKAGE_NAME = 'com.beautifier.provider';
const IOS_LINK_FOR_PARTNER = "https://apps.apple.com/in/app/handyman-provider-app/id1596025324";

const IOS_LINK_FOR_USER = 'https://apps.apple.com/us/app/handyman-service-user/id1591427211';

const DASHBOARD_AUTO_SLIDER_SECOND = 5;

const TERMS_CONDITION_URL = 'https://beautifierapp.com/#/term-conditions/';
const PRIVACY_POLICY_URL = 'https://beautifierapp.com/#/privacy-policy/';
const INQUIRY_SUPPORT_EMAIL = 'info@beautifierapp.com';

/// ChatGpt config
const ENABLE_CHATGPT = true; /// Enable ChatGpt
const TEST_WITHOUT_KEY_CHATGPT = true; /// Set Test Mode true or false
const CHATGPT_API_KEY = ''; /// Set ChatGPT key

/// You can add help line number here for contact. It's demo number
const HELP_LINE_NUMBER = '+966';

//Airtel Money Payments
///It Supports ["UGX", "NGN", "TZS", "KES", "RWF", "ZMW", "CFA", "XOF", "XAF", "CDF", "USD", "XAF", "SCR", "MGA", "MWK"]
const AIRTEL_CURRENCY_CODE = "MWK";
const AIRTEL_COUNTRY_CODE = "MW";
const AIRTEL_TEST_BASE_URL = 'https://openapiuat.airtel.africa/'; //Test Url
const AIRTEL_LIVE_BASE_URL = 'https://openapi.airtel.africa/'; // Live Url

//Phone Pay
const PHONE_PE_TEST_ENVIRONMENT = 'UAT';
const PHONE_PE_LIVE_ENVIRONMENT = 'PhonePeEnvironment.RELEASE';
const PHONE_PE_SALTINDEX = '1';

/// PAYSTACK PAYMENT DETAIL
const PAYSTACK_CURRENCY_CODE = 'NGN';
/// Nigeria Currency

/// STRIPE PAYMENT DETAIL
const STRIPE_MERCHANT_COUNTRY_CODE = 'IN';
const STRIPE_CURRENCY_CODE = 'INR';

/// RAZORPAY PAYMENT DETAIL
const RAZORPAY_CURRENCY_CODE = 'INR';

/// PAYPAL PAYMENT DETAIL
const PAYPAL_CURRENCY_CODE = 'USD';

/// SADAD PAYMENT DETAIL
const SADAD_API_URL = 'https://api-s.sadad.qa';
const SADAD_PAY_URL = "https://d.sadad.qa";

DateTime todayDate = DateTime(2022, 8, 24);

Country defaultCountry() {
  return Country(
    phoneCode: '966',
    countryCode: 'SA',
    e164Sc: 96,
    geographic: true,
    level: 1,
    name: 'Saudi Arabia',
    example: '96623456789',
    displayName: 'Saudi Arabia (SA) [+966]',
    displayNameNoCountryCode: 'Saudi Arabia (SA)',
    e164Key: '966-SA-0',
    fullExampleWithPlusSign: '+9669123456789',
  );
}
