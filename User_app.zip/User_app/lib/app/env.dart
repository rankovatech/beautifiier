/*
  Authors : initappz (Rahul Jograna)
  Website : https://initappz.com/
  App Name : Ultimate Salon Full App Flutter V2
  This App Template Source code is licensed as per the
  terms found in the Website https://initappz.com/license
  Copyright and Good Faith Purchasers © 2023-present initappz.
*/
class Environments {
  static const String appName = 'Beautifier';
  static const String companyName = '';
  static const String googleMapsKey = 'AIzaSyDnRzxKSgJiZwVl8_pjBdpvJ-mar5StS8w';
  static const String apiBaseURL =
      'https://api.beautifierksa.com/public/';
  static const String websiteURL = 'https://beautifierksa.com/';
}
