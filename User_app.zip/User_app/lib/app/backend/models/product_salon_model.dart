/*
  Authors : initappz (Rahul Jograna)
  Website : https://initappz.com/
  App Name : Ultimate Salon Full App Flutter V2
  This App Template Source code is licensed as per the
  terms found in the Website https://initappz.com/license
  Copyright and Good Faith Purchasers © 2023-present initappz.
*/
import 'dart:convert';

import 'package:jiffy/jiffy.dart';
import 'package:salon_user/app/backend/models/address_model.dart';
import 'package:salon_user/app/backend/models/products_list_model.dart';

class ProductSalonModel {
  int? id;
  int? uid;
  int? freelancerId;
  int? salonId;
  String? dateTime;
  String? paidMethod;
  String? orderTo;
  List<ProductsListModel>? orders;
  String? notes;
  AddressModel? address;
  double? total;
  double? tax;
  double? grandTotal;
  double? discount;
  String? driverId;
  double? deliveryCharge;
  int? walletUsed;
  double? walletPrice;
  String? couponCode;
  String? extra;
  String? payKey;
  int? status;
  int? payStatus;
  String? extraField;
  String? createdAt;
  String? type;
  SalonInfo? salonInfo;
  FreelancerInfo? freelancerInfo;
  OwnerInfoModel? ownerInfo;
  ProductSalonModel(
      {this.id,
      this.uid,
      this.freelancerId,
      this.salonId,
      this.dateTime,
      this.paidMethod,
      this.orderTo,
      this.orders,
      this.notes,
      this.address,
      this.total,
      this.tax,
      this.grandTotal,
      this.discount,
      this.driverId,
      this.deliveryCharge,
      this.walletUsed,
      this.walletPrice,
      this.couponCode,
      this.extra,
      this.payKey,
      this.status,
      this.payStatus,
      this.extraField,
      this.createdAt,
      this.type,
      this.salonInfo,
      this.freelancerInfo,
      this.ownerInfo});

  ProductSalonModel.fromJson(Map<String, dynamic> json) {
    id = int.parse(json['id'].toString());
    uid = int.parse(json['uid'].toString());
    freelancerId = int.parse(json['freelancer_id'].toString());
    salonId = int.parse(json['salon_id'].toString());
    dateTime = json['date_time'];
    paidMethod = json['paid_method'];
    orderTo = json['order_to'];
    if (json.containsKey('orders') &&
        json['orders'] != null &&
        json['orders'] != 'NA' &&
        json['orders'] != '') {
      orders = <ProductsListModel>[];
      var order = jsonDecode(json['orders']);
      order.forEach((element) {
        orders!.add(ProductsListModel.fromJson(element));
      });
    }
    notes = json['notes'];
    address = json['address'] != null
        ? AddressModel.fromJson(jsonDecode(json['address']))
        : null;
    total = double.parse(json['total'].toString());
    tax = double.parse(json['tax'].toString());
    grandTotal = double.parse(json['grand_total'].toString());
    discount = double.parse(json['discount'].toString());
    driverId = json['driver_id'];
    deliveryCharge = double.parse(json['delivery_charge'].toString());
    walletUsed = int.parse(json['wallet_used'].toString());
    walletPrice = double.parse(json['wallet_price'].toString());
    couponCode = json['coupon_code'];
    extra = json['extra'];
    payKey = json['pay_key'];
    status = int.parse(json['status'].toString());
    payStatus = int.parse(json['payStatus'].toString());
    extraField = json['extra_field'];
    createdAt = Jiffy(json['created_at']).yMMMMd;
    type = json['type'];
    if (json.containsKey('salonInfo')) {
      salonInfo = json['salonInfo'] != null
          ? SalonInfo.fromJson(json['salonInfo'])
          : null;
    }
    if (json.containsKey('freelancerInfo')) {
      freelancerInfo = json['freelancerInfo'] != null
          ? FreelancerInfo.fromJson(json['freelancerInfo'])
          : null;
    }
    if (json.containsKey('ownerInfo')) {
      ownerInfo = json['ownerInfo'] != null
          ? OwnerInfoModel.fromJson(json['ownerInfo'])
          : null;
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['uid'] = uid;
    data['freelancer_id'] = freelancerId;
    data['salon_id'] = salonId;
    data['date_time'] = dateTime;
    data['paid_method'] = paidMethod;
    data['order_to'] = orderTo;
    data['orders'] = orders;
    data['notes'] = notes;
    data['address'] = address;
    data['total'] = total;
    data['tax'] = tax;
    data['grand_total'] = grandTotal;
    data['discount'] = discount;
    data['driver_id'] = driverId;
    data['delivery_charge'] = deliveryCharge;
    data['wallet_used'] = walletUsed;
    data['wallet_price'] = walletPrice;
    data['coupon_code'] = couponCode;
    data['extra'] = extra;
    data['pay_key'] = payKey;
    data['status'] = status;
    data['payStatus'] = payStatus;
    data['extra_field'] = extraField;
    data['created_at'] = createdAt;
    data['type'] = type;
    if (salonInfo != null) {
      data['salonInfo'] = salonInfo!.toJson();
    }
    return data;
  }
}

class SalonInfo {
  String? name;
  String? cover;
  String? address;

  SalonInfo({this.name, this.cover, this.address});

  SalonInfo.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    cover = json['cover'];
    address = json['address'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['name'] = name;
    data['cover'] = cover;
    data['address'] = address;
    return data;
  }
}

class FreelancerInfo {
  int? id;
  String? firstName;
  String? lastName;
  String? cover;
  String? type;

  FreelancerInfo(
      {this.id, this.firstName, this.lastName, this.cover, this.type});

  FreelancerInfo.fromJson(Map<String, dynamic> json) {
    id = int.parse(json['id'].toString());
    firstName = json['first_name'];
    lastName = json['last_name'];
    cover = json['cover'];
    type = json['type'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['first_name'] = firstName;
    data['last_name'] = lastName;
    data['cover'] = cover;
    data['type'] = type;
    return data;
  }
}

class OwnerInfoModel {
  String? firstName;
  String? lastName;
  String? email;
  String? mobile;
  String? countryCode;
  String? fcmToken;
  String? cover;

  OwnerInfoModel(
      {this.firstName,
      this.lastName,
      this.email,
      this.mobile,
      this.countryCode,
      this.fcmToken,
      this.cover});

  OwnerInfoModel.fromJson(Map<String, dynamic> json) {
    firstName = json['first_name'];
    lastName = json['last_name'];
    email = json['email'];
    mobile = json['mobile'];
    countryCode = json['country_code'];
    fcmToken = json['fcm_token'];
    cover = json['cover'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['first_name'] = firstName;
    data['last_name'] = lastName;
    data['email'] = email;
    data['mobile'] = mobile;
    data['country_code'] = countryCode;
    data['fcm_token'] = fcmToken;
    data['cover'] = cover;
    return data;
  }
}
