package com.beautifier.owner

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
